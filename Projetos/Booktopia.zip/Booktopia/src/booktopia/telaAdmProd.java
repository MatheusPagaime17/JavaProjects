/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package booktopia;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author mathe
 */
public class telaAdmProd extends javax.swing.JFrame {

    
    private Connection conn;
    private PreparedStatement stmt;
    private ResultSet rs;
    /**
     * Creates new form telaAdmProd
     */
    public telaAdmProd() {
        initComponents();
        conectarAoBanco();
        atualizarTabela();
    }
    
    public void conectarAoBanco(){
        try {
            // Conectar ao banco de dados
            String url = "jdbc:mysql://localhost/mydb?useTimezone=true&serverTimezone=UTC";
            String usuario = "root";
            String senha = "root";
            conn = DriverManager.getConnection(url, usuario, senha);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Ocorreu algum erro inesperado, tente novamente mais tarde: " + ex.getMessage());
        }
    }
    
    private void atualizarTabela(){
        try {
            // Consultar todos os registros na tabela de clientes
            String sql = "SELECT * FROM tb_livro";
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            // Limpar tabela
            DefaultTableModel model = (DefaultTableModel) produtoTable.getModel();
            model.setRowCount(0);

            // Preencher a tabela com os registros
            while (rs.next()) {
                int id = rs.getInt("idtb_livro");
                String nome = rs.getString("tb_livro_nome");
                double preco = rs.getDouble("tb_livro_preço");
                String autor = rs.getString("tb_livro_autor");
                String pag = rs.getString("tb_livro_pag");
                String desc = rs.getString("tb_livro_desc");
                
                

                model.addRow(new Object[]{id, nome, preco, autor, pag, desc});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao consultar registros: " + ex.getMessage());
        }
    }
    
    private void atualizarLivro(){
        try {
            int id = Integer.parseInt(idProdtxt.getText());
            String nome = nomeProdtxt.getText();
            String preco = precoProdtxt.getText();
            String autor = autorProdtxt.getText();
            String pag = pagProdtxt.getText();
            String desc = descProdtxt.getText();
            

            // Atualizar cliente na tabela
            String sql = "UPDATE tb_livro SET tb_livro_nome = ?, tb_livro_preço = ?, tb_livro_autor = ?, tb_livro_pag = ?, tb_livro_desc = ? WHERE idtb_livro = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, nome);
            stmt.setString(2, preco);
            stmt.setString(3, autor);
            stmt.setString(4, pag);
            stmt.setString(5, desc);
            stmt.setInt(6, id);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Livro atualizado com sucesso!");

            // Limpar campos de entrada
            idProdtxt.setText("");
            nomeProdtxt.setText("");
            precoProdtxt.setText("");
            autorProdtxt.setText("");
            pagProdtxt.setText("");
            descProdtxt.setText("");
            

            atualizarTabela();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao atualizar Livro: " + ex.getMessage());
        }
    }
    private void excluirLivro(){
        try {
            int id = Integer.parseInt(idProdtxt.getText());

            // Excluir cliente da tabela
            String sql = "DELETE FROM tb_livro WHERE idtb_livro = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Livro excluído com sucesso!");

            // Limpar campos de entrada
            idProdtxt.setText("");
            nomeProdtxt.setText("");
            precoProdtxt.setText("");
            autorProdtxt.setText("");
            pagProdtxt.setText("");
            descProdtxt.setText("");
            

            atualizarTabela();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao excluir Livro: " + ex.getMessage());
        }
    }
    private void inserirLivro(){
         try {
            String nome = nomeProdtxt.getText();
            String preco = precoProdtxt.getText();
            String autor = autorProdtxt.getText();
            String pag = pagProdtxt.getText();
            String desc = descProdtxt.getText();

            // Inserir cliente na tabela
            String sql = "INSERT INTO tb_livro (tb_livro_nome, tb_livro_preço, tb_livro_autor, tb_livro_pag, tb_livro_desc) VALUES (?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, nome);
            stmt.setString(2, preco);
            stmt.setString(3, autor);
            stmt.setString(4, pag);
            stmt.setString(5, desc);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Livro inserido com sucesso!");

            // Limpar campos de entrada
            idProdtxt.setText("");
            nomeProdtxt.setText("");
            precoProdtxt.setText("");
            autorProdtxt.setText("");
            pagProdtxt.setText("");
            descProdtxt.setText("");

            atualizarTabela();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao inserir Livro: " + e.getMessage());
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        produtoTable = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        btnInserirProd = new javax.swing.JButton();
        btnExcluirProd = new javax.swing.JButton();
        idProdtxt = new javax.swing.JTextField();
        nomeProdtxt = new javax.swing.JTextField();
        precoProdtxt = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnAtualizarProd = new javax.swing.JButton();
        pagProdtxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        descProdtxt = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        autorProdtxt = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        btnVoltarAdm = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(470, 200));

        jPanel2.setBackground(new java.awt.Color(16, 23, 40));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel2.setPreferredSize(new java.awt.Dimension(600, 330));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        produtoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Preço", "Autor", "Paginas", "Descrição"
            }
        ));
        jScrollPane1.setViewportView(produtoTable);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 70, 550, 250));

        jLabel2.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\mathe\\Downloads\\pequeno.png")); // NOI18N
        jLabel2.setText("Booktopia");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, -1, -1));

        btnInserirProd.setBackground(new java.awt.Color(51, 255, 51));
        btnInserirProd.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        btnInserirProd.setText("Inserir");
        btnInserirProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInserirProdActionPerformed(evt);
            }
        });
        jPanel2.add(btnInserirProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 330, -1, -1));

        btnExcluirProd.setBackground(new java.awt.Color(255, 0, 51));
        btnExcluirProd.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        btnExcluirProd.setText("Excluir");
        btnExcluirProd.setBorderPainted(false);
        btnExcluirProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirProdActionPerformed(evt);
            }
        });
        jPanel2.add(btnExcluirProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 330, -1, -1));

        idProdtxt.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jPanel2.add(idProdtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 370, 40, -1));
        jPanel2.add(nomeProdtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, 100, -1));

        precoProdtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                precoProdtxtActionPerformed(evt);
            }
        });
        jPanel2.add(precoProdtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 430, 100, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Preço:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 430, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Id:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 370, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Nome:");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 400, -1, -1));

        btnAtualizarProd.setBackground(new java.awt.Color(51, 51, 255));
        btnAtualizarProd.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        btnAtualizarProd.setText("Atualizar");
        btnAtualizarProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarProdActionPerformed(evt);
            }
        });
        jPanel2.add(btnAtualizarProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 330, -1, -1));
        jPanel2.add(pagProdtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 450, 70, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Descrição:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 370, -1, -1));

        descProdtxt.setColumns(20);
        descProdtxt.setRows(5);
        jScrollPane2.setViewportView(descProdtxt);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 370, 240, 70));

        jLabel6.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("N° de Páginas:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 450, -1, -1));

        autorProdtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                autorProdtxtActionPerformed(evt);
            }
        });
        jPanel2.add(autorProdtxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 460, 100, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Autor:");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 460, -1, -1));

        btnVoltarAdm.setBackground(new java.awt.Color(16, 23, 40));
        btnVoltarAdm.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        btnVoltarAdm.setForeground(new java.awt.Color(255, 255, 255));
        btnVoltarAdm.setIcon(new javax.swing.ImageIcon("C:\\Users\\mathe\\Downloads\\back.png")); // NOI18N
        btnVoltarAdm.setText("Voltar");
        btnVoltarAdm.setBorder(null);
        btnVoltarAdm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarAdmActionPerformed(evt);
            }
        });
        jPanel2.add(btnVoltarAdm, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnInserirProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInserirProdActionPerformed
        inserirLivro();
    }//GEN-LAST:event_btnInserirProdActionPerformed

    private void btnExcluirProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirProdActionPerformed
        excluirLivro();
    }//GEN-LAST:event_btnExcluirProdActionPerformed

    private void btnAtualizarProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarProdActionPerformed
        atualizarLivro();
    }//GEN-LAST:event_btnAtualizarProdActionPerformed

    private void precoProdtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_precoProdtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_precoProdtxtActionPerformed

    private void autorProdtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_autorProdtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_autorProdtxtActionPerformed

    private void btnVoltarAdmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarAdmActionPerformed
        telaEscolherAdm escolher = new telaEscolherAdm();
        escolher.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnVoltarAdmActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(telaAdmProd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(telaAdmProd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(telaAdmProd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(telaAdmProd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new telaAdmProd().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField autorProdtxt;
    private javax.swing.JButton btnAtualizarProd;
    private javax.swing.JButton btnExcluirProd;
    private javax.swing.JButton btnInserirProd;
    private javax.swing.JButton btnVoltarAdm;
    private javax.swing.JTextArea descProdtxt;
    private javax.swing.JTextField idProdtxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField nomeProdtxt;
    private javax.swing.JTextField pagProdtxt;
    private javax.swing.JTextField precoProdtxt;
    private javax.swing.JTable produtoTable;
    // End of variables declaration//GEN-END:variables
}
